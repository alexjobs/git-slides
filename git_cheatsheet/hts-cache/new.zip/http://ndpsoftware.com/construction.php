<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>
      NDP Software ::
Construction    </title>
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0"/>
    <link rel="SHORTCUT ICON" href="favicon.ico" />
    <meta name="msvalidate.01" content="B24F365C5258BA8C65E423307692C32E" />
        <link rel="stylesheet" href="fonts/Impact-Label-fontfacekit/stylesheet.css" type="text/css"/>
    <link rel="stylesheet" type="text/css" href="css/ndp-print.css" media="print" />
    <link rel="stylesheet" type="text/css" href="css/ndp.css" media="screen" />
            <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script type="text/javascript" src="js/csster.js"></script>
    <script type="text/javascript" src="js/color_factory.js"></script>
    <script type="text/javascript" src="js/jquery.boxes.js"></script>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-1458227-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>


  </head>
  <body class="" onload="">
    <div id="margin">
      <div id="page">
        <div id="new_header">
           <h1><span>&nbsp;NDP Software&nbsp;</span></h1>
           <h2>Compelling Software &bull; Design & Construction</h3>
        </div>
      
        <div id="header" class="screenOnly">
          <h1>
            Andrew J. Peterson
          </h1>
        <h1>
          Compelling Software, Design and Development
        </h1>
      <h1>
        NDP Software
      </h1>
    <h1>
      Andrew Peterson, Consultant
    </h1>
</div>
<div id="menu" class="screenOnly">
  <div class="menu">
    <ul>
      <!--li>
        NDP Software 
      </li-->
      <li>
        <a href="index.php" title="Overview of the software consulting business">
          About NDP Software
        </a>
      </li>
      <li>
        <a href="visualization.php" title="Interactions and Visualizations">
          Visualization
        </a>
      </li>
      <li>
        <a href="prototype.php" title="Prototypes">
          Prototype
        </a>
      </li>
      <li>
        <a href="consulting.php" title="Consulting projects and areas of expertise">
          Software Consultant
        </a>
      </li>
<!--      <li>
        <a href="web.php" title="Web-related software projects">
          Web Development
        </a>
      </li>
      <li>
        <a href="software.php" title="Custom-built software">
          Software Development
        </a>
      </li> -->
      <li>
        <a href="clients.php" title="Clients of NDP Software">
          Clients
        </a>
      </li>
      <li>
        <a href="http://blog.ndpsoftware.com/" target="_blank">Blog</a>
      </li>
      <li>
        <a href="http://github.com/ndp" target="_blank">Github Repo</a>
      </li>
      <li>
        <a href="http://amp-what.com" target="_blank">Amp What</a>
      </li>
      <li>
        <a href="https://plus.google.com/111325326458556506982/posts?rel=author">Google+</a>
      </li>
      <li class="email">
         <a href="mailto:andy@ndpsoftware.com">Email</a>
      </li>
      <li class="linked_in">
        <script src="//platform.linkedin.com/in.js" type="text/javascript"></script>
        <script type="IN/MemberProfile" data-id="http://www.linkedin.com/in/ndpsoftware" data-format="hover" data-related="false"></script>
      </li>
      <!--li class="social">
        <g:plusone size="small" annotation="inline" width="160"></g:plusone>
      </li-->
    </ul>
  </div>
</div>
<div id="content">
  <h2>
Construction  </h2>
<div style="float:right;font-size: 80%; text-align: center; padding-left: 20px;margin-right: -220px">	<img src="images/IMG_3112.JPG" alt="scaffolding" border="1" />	<br />	Building Scaffolding</div><p>	October 2003 through January 2005, I was the project managing our house construction. We kept a small front portion (living room, dining room and vestibule) and added three bedrooms, three baths and a kitchen in the back. (We have managed to do this without losing any yard space!) </p><p>	During this process, I have learned tons the business. As my contractor, Tony Szeto says, "You think too much". Well, he's right. I make too many spreadsheets too.</p><p>	When trying to select energy-efficient appliances I have had to do a bit of searching. Here are the results of some of it. </p><p>	If you are interested in good suppliers in San Francisco, let me know. I will refer you to the people we ended up liking. It seems to be just a small subset of your options. </p><p>	All items below are copyright (c) 2003-2005 Andrew Peterson. All Rights Reserved. Go ahead and use them for educational purposes, and let me know what you do.</p><table class="prosVsCons">	<tr>		<th colspan="2">			<h4 style="font-size: 150%; text-align: center; padding-bottom: 15px;padding-top: 0px;">				Tankless Water Heaters			</h4>		</th>	</tr>	<tr>		<th>			Pros		</th>		<th>			Cons		</th>	</tr>	<tr>		<td>			<ul>				<li>					They are more efficient, and therefore save gas. For me, the energy efficiency was very important. We now have three more kids than we had before, so it's hard to say whether we got the efficiency, but I am sure we do. 				</li>				<li>					You are promised that they last longer. I believe this, but cannot speak from experience. So far so good.				</li>				<li>					They are smaller than tanked water heaters, which can be important.				</li>				<li>					Unlimited hot water! Of course, as shower lengths approach infinity, energy conservation goes away.				</li>			</ul>		</td>		<td>			<ul>				<li>					They are expensive. You can save a bit by shopping around, especially on the internet. I would definitely recommend doing that. We bought ours at JC plumbing (which I generally recommend), but the water heaters aren't well priced there. I did it because (I thought) I was in a hurry. 				</li>				<li>					some plumbers will be confused if they haven't installed them before. Our plumber was awful, and I had to call the manufacturer to get it installed and have had to adjust the temperature myself-- not that big a deal, but it's enough different that it will confuse people. 				</li>				<li>					The venting requirements may be different than tanked water heaters. This needs to be analyzed to see if it'll be a problem. There were several problems with the city inspectors around ours, even though the instructors were quite clear-- lots of plumbers won't read the instructions. 				</li>				<li>					The venting is much more expensive than regular venting, and you should take the whole installation cost into account if this is a factor. 				</li>				<li>					The units are louder than regular water heaters. We installed one nearby our master bedroom and you definitely hear it fire up and run the exhaust fan. You get used to it. 				</li>			</ul>			</td>	</tr>	<tr>		<td colspan="2">			<h4>				Also note:			</h4>			<ul>				<li>					You want to put the unit as close to where it will be used as possible (taking into account the noise, as mentioned above). I installed our fairly close to the sinks and bathroom, but it takes a while to warm up. Although it can't be, it seems like longer than a traditional water heater. The latency is in the pipes, and proportional to the length of them. The only thing that I can figure out is that the pipes stay cooler because they are not connected to a hot tank of water all the time.. Beforehand I read that we should insulate the pipes, which I wanted to do, but was talked out of it by both our architect and contractor. I really wish I had. There is simple, easy to install pipe insulation you can get if you have access to the pipes. I would suspect this would improve the situation. 				</li>				<li>					We installed two water heaters since our bathrooms are so far apart, and I was a little nervous about the flow rate. You can decide whether you absolutely have to have hot water from three taps at the same time, or whether you'll put up with slightly less hot water during busy times. I think I could have gotten away with two smaller units than I ended up getting. 				</li>			</ul>		</td>	</tr></table><h3>	Water Usage for Tankless Water Heaters (Requires Excel)</h3><h4>	<a href="construction/On-demand_water_usage.xls">		Water (Requires Excel)</a></h4><p>	Calculate the water load for an On-demand (or "Tankless") water heater. I also wanted to compare the various models that are available. The information is generally inconsistently presented from manufacturers, and this provides a framework to compare different manufacturer's models. 	<i>		The secret is that most of the units have the same efficiency, so you can compare the energy consumption direction, and not worry about the degrees/gallon/hour calculations.	</i></p><h3>	Electrical Load</h3><h4>	<a href="construction/Electrical_Load_Analysis.xls">		Electrical Load Calculator (Requires Excel)</a></h4><p>	Plug in the electrical loads and it will determine how to split the circuits. I would think this would be readily available, but I didn't find it. This also does usage analysis, for energy consumption calculations. It is not perfect, but it should get you started.	<br />	Enter your loads on the first worksheet, and then update the pivot tables on the other pages. This should get you started. </p><div style="font-size: 80%; text-align: center; width: 100%">	<img src="images/IMG_3102.JPG" alt="master bedroom" border="1" />	<br />	Master bedroom 	<br />	<br />	<img src="images/IMG_3192.JPG" alt="board-form for foundation" border="1" />	<br />	New foundation under existing structure</div></div>
<!--id content -->
<div id="footer" >
  <table class="sitemap screenOnly">
    <tr>
      <td>
        <div class="menu cheatsheets">
          <ul>
            <li title="Short summaries of detailed technical topics">
              Cheat Sheets 
            </li>
            <li>
              <a class="new" href="git-cheatsheet.html">
                Visual Git Cheatsheet
              </a>
            </li>
            <li>
              <a href="HibernateMappingCheatSheet.html" title="Short hibernate mapping examples, without the detailed explanations.">
                Hibernate Mapping
              </a>
            </li>
            <li>
              <a class="updated" href="JSPXMLCheatSheet.html" title="JSPs with XML? A simple summary of the most useful and used constructs">
                JSP 2.0 XML Documents
              </a>
            </li>
            <li>
              <a href="http://amp-what.com" title="A quick, interactive reference of 11,500 HTML character entities">&amp;what (amp-what.com)</a>
            </li>
            <li>
              XSLT 
            </li>
            <li>
              <a href="downloads-xsl-struts.php">
                Struts Xslt
              </a>
            </li>
            <li>
              <a href="downloads-xsl-resume.php">
                Xslt for My Resume
              </a>
            </li>
          </ul>
        </div>
      </td>
      <td>
        <div class="menu technical">
          <ul>
            <li>
              CSS 
            </li>
            <li>
              <a class="updated" href="CssBestPractices.php">
                CSS Best Practices
              </a>
            </li>
            <li>
              <a href="cssExperiments.php">
                CSS Experiments
              </a>
            </li>
            <li>
              <a href="css.php">
                CSS Links
              </a>
            </li>
            <li>
              Javascript 
            </li>
            <li>
              <a href="http://github.com/ndp/csster" class="new" >
                Csster
              </a>
            </li>
            <li>
              <a href="ScriptaculousEffectsDemo.php" class="new" >
                Scriptaculous Effects Demo
              </a>
            </li>
            <li>
                <a href="http://github.com/ndp/jsutils" class="new" >
                    Javascript Playground
                </a>
            </li>
            <li>
              jQuery Plugins
            </li>
            <li>
              <a href="show_char_limit.php" class="new" >
                Show Char Limit
              </a>
            </li>
            <li>
              <a href="http://github.com/ndp/align-column" class="new" >
                Align Column
              </a>
            </li>
            <li>
              <a href="http://github.com/ndp/fixie" class="new" >
                Fixie
              </a>
            </li>
            <li>
              <a href="http://github.com/ndp/wizardize" class="new" >
                Wizardize
              </a>
            </li>
            <li>
              <a href="http://github.com/ndp/color_spy" class="new" >
                Color Spy
              </a>
            </li>
          </ul>
        </div>
      </td>
      <td>
        <div class="menu technical">
          <ul>
            <li>
              Other Technical 
            </li>
            <!--li>
              <a href="books.php" title="Books we like">
                Books
              </a>
            </li-->
            <li>
              <a href="isbn.php">
                ISBN Excel Converter
              </a>
            </li>
            <li>
              <a class="new" href="agile_methods/agile_methods.html">
                Agile Methods Visualization
              </a>
            </li>
            <li>
              <a class="new" href="softwareDevMaturityModel.php">
                Software Development Maturity Model
              </a>
            </li>
            <li>
              <a class="new" href="/OpenUpBasic/index.htm" target="_blank">
                OpenUP/Basic
              </a>
            </li>
            <li>
              <a class="new" href="other.php">
                Other Projects
              </a>
            </li>
            <li>
              <a href="http://blog.ndpsoftware.com/" target="_blank">My Blog</a>
            </li>
            <li>
              <a href="about.php"> 
                About This Site
              </a>
            </li>
          </ul>
        </div>
      </td>
      <td>
        <div class="menu nontechnical">
          <ul>
            <li>
              Non-technical 
            </li>
            <li>
              <a href="http://delicious.com/ndp" target="_blank">
                  delicious/ndp
              </a>
            </li>
            <li>
              <a href="http://ical.mac.com/WebObjects/iCal.woa/wa/default?u=ndp&amp;n=ndp.ics" target="_blank">
                Calendar
              </a>
            </li>
            <li>
              <a href="construction.php">
                Construction
              </a>
            </li>
            <!--<li>-->
              <!--<a href="http://priita.com" target="_blank">-->
                <!--Priita.com-->
              <!--</a>-->
            <!--</li>-->
            <!--<li>-->
              <!--<a href="http://homepage.mac.com/ndp" target="_blank">-->
                <!--Photos-->
              <!--</a>-->
            <!--</li>-->
            <!--<li>-->
              <!--<a href="http://tanyandy.com" target="_blank">-->
                <!--Tanyandy.com-->
              <!--</a>-->
            <!--</li>-->
          </ul>
        </div>
      </td>
    </tr>
  </table>
  <div class="footnotes screenOnly">
    <div class="menu technical">
      <ul>
        <li>
          <span class='st_email'></span>
            <span class='st_stumbleupon'></span>
             <span class='st_twitter'></span>
            <span class='st_googleplus'></span>
            <span class='st_facebook'></span>
            <span class='st_wordpress'></span>
            <span class='st_hatena'></span>
            <span class='st_delicious'></span>
            <span class='st_blogger'></span>
            <span class='st_tumblr'></span>
            <span class='st_reddit'></span>
            <span class='st_linkedin'></span>
        </li>
      </ul>
    </div>
  </div>
  <div class="copyright">
    Copyright (c) 1999-2013 Andrew J. Peterson.
    <a href="mailto:andy@ndpsoftware.com">
      andy@ndpsoftware.com</a>. 
  </div>

</div>
</div>
</div>
<script type="text/javascript">
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>      
<script type="text/javascript">var switchTo5x=false;</script><script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script><script type="text/javascript">stLight.options({publisher:'34a76a8b-d635-4885-8b9c-78fbf9a6d08d'});</script>
</body>
</html>
