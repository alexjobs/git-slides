<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd" />
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>
			Script.aculo.us Effects Demo
		</title>
		<link rel="stylesheet" href="css/undohtmlx.css" type="text/css">
		</link>
		<link rel="stylesheet" href="css/cheatSheet.css" type="text/css">
		</link>
<script src="js/prototype.js"></script> <script src="js/scriptaculous/scriptaculous.js"></script> <script src="js/scriptaculous/effects.js"></script> 
		<link src="http://wiki.script.aculo.us/stylesheets/script.aculo.us.css" type="text/css" />
<style>
    html {
      font-family: verdana, arial, sans-serif;
      font-size: medium;
      color: #000;
      background-color: #fff;
      padding: 0;
      margin: 0;
    }
    body {
      padding: 0;
      margin: 0;
    }
    h1 {
      font-size: 40px;
      color: #694;
      background-color: #9c7;
      width: 100%;
      padding: 15px 15px 15px 15px;
      border-bottom: 5px solid #694;
      margin: 0 0 10px 0;
    }
    table#layout {
      width: 1150px;
      width: 90%;
    }

    td {
      vertical-align: top;
    }
    td.how,
    td.watch,
    td.what {
    	padding: 10px;
    }

    h2 {
    	font-size: 30px;
    	color: #ccc;
    	background-color: transparent;
    	text-align: center;
    	text-align: left;
    }

	p {
		font-size: small;
		color: #555;
		margin: 0 0 5px 0;
	}


	#status {
		color: #e8a400;
	}

    .example-container {
      height: 400px;
      width: 300px;
    }

    .example {
      background-color: #ecf3e1;
      color:#444444;
      padding: 5px;
      font-size: small;
      text-align: left;
      width: 300px;
      height: auto;
      border: 3px solid #7f9f50;
    }

    .example h3 {
      padding: 0;
      margin: 6px 3px;
      font-size: medium;
      background-color:transparent;
    }
    .example p {
      padding: 0;
      margin: 6px 3px;
    }
    .example img {
      margin: 20px;
      border: 1px solid #333;
    }
    .example li {
    	display: list-item;
    }

    table#controls th {
      padding: 20px 1ex 10px 1ex;
      color: #4a6c19;
      text-transform: capitalize;
    }

    table#controls td a,
    .what a {
      display: block;
      text-align: center;
      background-color:#ecf3e1;
      color: #7f9f50;
      border: 3px solid #ecf3e1;
      padding: 5px;
      cursor: pointer;
      margin: 0 10px 0 10px;
      white-space: nowrap;
    }

    table#controls td a:hover,
    .what a:hover {
      border-color: #7e9e50;
      background-color: #c5dea1;
    }

	p.ref {
	  padding: 20px 10px;
	  font-size: small;
	}
    p.ref a {
      color: #7e9e50;
    }
	div#footer {
		width: 100%;
	}
  </style>
  <script>
  var running = false;
  var keepRunning = false;
  var effect;
  var element = 'demo-all';

  function demo(s)
  {
    effect = s;
    keepRunning = true;
  }

  function appearQuickly()
  {
    Effect.Appear(element, {delay: 1, duration: .1, afterFinish:demoDone});
  }
  
  function demoDone() {
	   running = false;
		window.status = '';
	$('status').innerHTML = "";

	  if (keepRunning)
	  {
		demoStart();
	  }
	}

  function demoStart()
  {
    if (!running)
    {
      running = true;
      window.status = 'Running ' + effect + '.';
      $('status').innerHTML = effect;
      switch (effect)
              {
        case 'Fade':
          Effect.Fade(element, {delay: .1, duration: 3, afterFinish: appearQuickly });
          break;

        case 'Appear':
          Effect.Fade(element, {delay: .1, duration: .1, afterFinish: function()
          {
            Effect.Appear(element, {delay: 1, duration: 3, afterFinish:demoDone});
          }});
          break;


        case 'Grow':
          Effect.Shrink(element, {delay: .1, duration: .1, afterFinish: function()
          {
            Effect.Grow(element, {delay: 1, duration: 2, afterFinish:demoDone});
          }});
          break;

        case 'Puff':
          Effect.Puff(element, {delay: .1, duration: 2, afterFinish: appearQuickly});
          break;

        case 'BlindUp':
          Effect.BlindUp(element, {delay: .1, duration: 2, afterFinish: appearQuickly});
          break;

        case 'DropOut':
          Effect.DropOut(element, {delay: .1, duration: 2, afterFinish: appearQuickly});
          break;

        case 'SlideDown':
          Effect.SlideDown(element, {delay: .1, duration: 2, afterFinish: appearQuickly});
          break;

        case 'SlideUp':
          Effect.SlideUp(element, {delay: .1, duration: 2, afterFinish: appearQuickly});
          break;

        case 'SwitchOff':
          Effect.SwitchOff(element, {delay: .1, duration: 2, afterFinish: appearQuickly});
          break;

        case 'Squish':
          Effect.Squish(element, {delay: .1, duration: 2, afterFinish: appearQuickly});
          break;

        case 'Fold':
          Effect.Fold(element, {delay: .1, duration: 2, afterFinish: appearQuickly});
          break;

        case 'Shrink':
          Effect.Shrink(element, {delay: .2, duration: 2, afterFinish: function()
          {
            Effect.Grow(element, {delay: 1, duration: .2, afterFinish:demoDone});
          }});
          break;

        case 'BlindDown':
          Effect.BlindDown(element, {delay: .1, duration: 3, afterFinish: appearQuickly});
          break;

        case 'Shake':
          Effect.Shake(element, {delay: .1, duration: 3, afterFinish: function()
          {
            alert("Shake DONE doesn't get called");
            running = false;
            if (keepRunning)
            {
              demoStart();
            }
          }});
          break;

        case 'Pulsate':
          Effect.Pulsate(element, {delay: .1, duration: 2, afterFinish: demoDone});
          break;

        case 'Highlight-#fff-#f00':
          new Effect.Highlight(element, {delay: .1, duration: 3, startColor:'#fff', endColor:'#f00', afterFinish: demoDone});
          break;

        case 'Highlight-#00f-#0f0':
          new Effect.Highlight(element, {delay: .1, duration: 3, startColor:'#00f', endColor:'#0f0', afterFinish: demoDone});
          break;

        default:
          alert('Unknown case: ' + effect);
      }
    }
  }
  function demoStop()
  {
    keepRunning = false;
  }
  function demoElement(e) {
	Effect.BlindUp(element, {duration: .5, afterFinish: function() {
		$('demo-all').innerHTML="<div>"+$(e).innerHTML+"</div>";
		Effect.BlindDown(element, {duration: .3});
	}});
  }
  </script>
        <script type="text/javascript">

          var _gaq = _gaq || [];
          _gaq.push(['_setAccount', 'UA-1458227-1']);
          _gaq.push(['_trackPageview']);

          (function() {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
          })();

        </script>
    
	</head>
	<body>
		<h1>
			Scriptaculous Effects Demo
		</h1>
		<table id="layout">
			<tr>
				<td class="what">
					<h2>
						What
					</h2>
					<p>
						Click to choose content.
					</p>
					<a onclick="document.location = document.location">
						Mixed Media
					</a>
					<a onclick="demoElement('example-list')">
						List
					</a>
					<a onclick="demoElement('example-image')">
						Image
					</a>
					<a onclick="demoElement('example-form')">
						Form
					</a>
					<a onclick="demoElement('example-para')">
						Paragraph
					</a>
					<a onclick="demoElement('example-text')">
						Text
					</a>
				</td>

				<td class="how">
					<h2>
						How
					</h2>
					<p>
						Move the mouse over the effect to watch it.
					</p>
					<table cellpadding="0" cellspacing="0" id="controls">
						<tr>
							<th>
								Show
							</th>
							<th>
								Hide
							</th>
						</tr>
						<tr>
							<td>
								<a onmouseover="demo('Appear'); demoStart()" onmouseout="demoStop()">
									Fade-in (Appear)
								</a>
							</td>
							<td>
								<a onmouseover="demo('Fade'); demoStart()" onmouseout="demoStop()">
									Fade
								</a>
							</td>
						</tr>
						<tr>
							<td>
								<a onmouseover="demo('BlindDown'); demoStart()" onmouseout="demoStop()">
									BlindDown
								</a>
							</td>
							<td>
								<a onmouseover="demo('BlindUp'); demoStart()" onmouseout="demoStop()">
									BlindUp
								</a>
							</td>
						</tr>
						<tr>
							<td>
								<a onmouseover="demo('SlideDown'); demoStart()" onmouseout="demoStop()">
									SlideDown
								</a>
							</td>
							<td>
								<a onmouseover="demo('SlideUp'); demoStart()" onmouseout="demoStop()">
									SlideUp
								</a>
							</td>
						</tr>
						<tr>
							<td>
								<a onmouseover="demo('Grow'); demoStart()" onmouseout="demoStop()">
									Grow
								</a>
							</td>
							<td>
								<a onmouseover="demo('Shrink'); demoStart()" onmouseout="demoStop()">
									Shrink
								</a>
							</td>
						</tr>
						<tr>
							<td>
							</td>
							<td>
								<a onmouseover="demo('Puff'); demoStart()" onmouseout="demoStop()">
									Puff
								</a>
								<a onmouseover="demo('DropOut'); demoStart()" onmouseout="demoStop()">
									DropOut
								</a>
								<a onmouseover="demo('SwitchOff'); demoStart()" onmouseout="demoStop()">
									SwitchOff
								</a>
<!--a onmouseover="demo('Squish'); demoStart()" onmouseOut="demoStop()">Squish</a-->
								<a onmouseover="demo('Fold'); demoStart()" onmouseout="demoStop()">
									Fold
								</a>
							</td>
						</tr>
						<tr>
							<th colspan="2">
								Emphasis
							</th>
						</tr>
						<tr>
							<td colspan="2">
<!--a onmouseover="demo('Shake'); demoStart()" onmouseOut="demoStop()">Shake</a doesn't call final method-->
								<a onmouseover="demo('Pulsate'); demoStart()" onmouseout="demoStop()">
									Pulsate
								</a>
								<a onmouseover="demo('Highlight-#fff-#f00'); demoStart()" onmouseout="demoStop()">
									Highlight
								</a>
							</td>
						</tr>
					</table>
				</td>
				<td class="watch">
					<h2>
						Watch
					</h2>
					<p>Now playing: <span id="status">none</span></p>
					<div class="example-container">
						<div class="example" id="demo-all">
							<h3>
								Example Heading
							</h3>
							<p>
								Move your mouse over the words at the left to see how an effects work. Holding your mouse over the effect with repeat it. If you move your mouse over another effect, it will start when the previous effect finishes.
							</p>
							<label for="x">
								Please enter: 
							</label>
							<input type="text" size="10" id="x" value="example">
							</input>
							<div>
								<img src="http://www.blm.gov/heritage/HE_Kids/images/10000_20picture.jpg" alt="" />
							</div>
							<ol>
								<li>
									Curly
								</li>
								<li>
									Larry
								</li>
								<li>
									Moe
								</li>
								<li>
									Schemp
								</li>
							</ol>
						</div>
					</div>
				</td>
			</tr>
		</table>
		<div id="footer">
		
					<p class="ref">
						Written by Andrew J. Peterson / NDP Software, Dec 15, 2006.
						<br />
						Please send comments, requests and contributions to 
						<a href="mailto:andy@ndpsoftware.com">
							andy@ndpsoftware.com</a>.
					</p>
					<p class="ref">
						See effects reference here: 
						<br />
						<a href="http://wiki.script.aculo.us/scriptaculous/show/VisualEffects">
							wiki.script.aculo.us/scriptaculous/show/VisualEffects</a>
					</p>

		
			<a href="http://validator.w3.org/check?uri=referer">
				<img src="http://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
			</a>
			<a href="http://jigsaw.w3.org/css-validator/check?uri=referer">
				<img style="border:0;width:88px;height:31px" src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Valid CSS!" />
			</a>
<!--Creative Commons License-->
			<a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/2.5/">
				<img alt="Creative Commons License" src="http://creativecommons.org/images/public/somerights20.png" />
			</a>
			<br />
			This work is licensed under a 
			<a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/2.5/">
				Creative Commons Attribution-NonCommercial-NoDerivs 2.5 License</a>. 
<!--/Creative Commons License-->
<!-- <rdf:RDF xmlns="http://web.resource.org/cc/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
    <Work rdf:about="">
      <license rdf:resource="http://creativecommons.org/licenses/by-nc-nd/2.5/" />
  <dc:type rdf:resource="http://purl.org/dc/dcmitype/Text" />
    </Work>
    <License rdf:about="http://creativecommons.org/licenses/by-nc-nd/2.5/"><permits rdf:resource="http://web.resource.org/cc/Reproduction"/><permits rdf:resource="http://web.resource.org/cc/Distribution"/><requires rdf:resource="http://web.resource.org/cc/Notice"/><requires rdf:resource="http://web.resource.org/cc/Attribution"/><prohibits rdf:resource="http://web.resource.org/cc/CommercialUse"/></License></rdf:RDF> -->
		</div>
		
		
		
		
		
		
		
		
		
		
		
		
							<div style="display: none">
						EXAMPLES that we can pull in 
						<div id="example-list">
							<ol>
								<li>
									Curly
								</li>
								<li>
									Larry
								</li>
								<li>
									Moe
								</li>
								<li>
									Schemp
								</li>
								<li>
									Curly Joe
								</li>
							</ol>
						</div>
						<div id="example-para">
							<p>
								Move your mouse over the words at the left to see how an effects work. Holding your mouse over the effect with repeat it. If you move your mouse over another effect, it will start when the previous effect finishes.
							</p>
						</div>
						<div id="example-text">
								<p>
								Move your mouse over the words at the left to see how an effects work. Holding your mouse over the effect with repeat it. If you move your mouse over another effect, it will start when the previous effect finishes.
								</p>
								<p>
									NOTE: In order to get multiple paragraphs to work well for the slide effects, you must wrap them in an enclosing element, like a div.
								</p>
								<p>
									Some of the effects apparently grab the first, rather than all the enclosing elements.
								</p>
						</div>
						<div id="example-image">
							<img src="http://www.blm.gov/heritage/HE_Kids/images/10000_20picture.jpg" alt="" />
						</div>
						<div id="example-form">
							<label for="x">
								Please enter: 
							</label>
							<input type="text" size="10" id="x" value="example">
							<br />
							</input>
							<label for="x">
								Please enter: 
							</label>
							<input type="text" size="10" id="x" value="example">
							</input>
							<br />
							<label for="x">
								Please enter: 
							</label>
							<input type="text" size="10" id="x" value="example">
							</input>
							<br />
							<label for="x">
								Please enter: 
							</label>
							<input type="text" size="10" id="x" value="example">
							</input>
						</div>
					</div>


<script type="text/javascript" src="http://crazyegg.com/pages/scripts/0003/7863.js"> </script>

	</body>
</html>
