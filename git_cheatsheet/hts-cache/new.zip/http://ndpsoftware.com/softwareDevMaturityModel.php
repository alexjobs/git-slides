<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>
      NDP Software ::
Software Development Maturity Model    </title>
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0"/>
    <link rel="SHORTCUT ICON" href="favicon.ico" />
    <meta name="msvalidate.01" content="B24F365C5258BA8C65E423307692C32E" />
        <link rel="stylesheet" href="fonts/Impact-Label-fontfacekit/stylesheet.css" type="text/css"/>
    <link rel="stylesheet" type="text/css" href="css/ndp-print.css" media="print" />
    <link rel="stylesheet" type="text/css" href="css/ndp.css" media="screen" />
            <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script type="text/javascript" src="js/csster.js"></script>
    <script type="text/javascript" src="js/color_factory.js"></script>
    <script type="text/javascript" src="js/jquery.boxes.js"></script>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-1458227-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>


  </head>
  <body class="showLinks" onload="">
    <div id="margin">
      <div id="page">
        <div id="new_header">
           <h1><span>&nbsp;NDP Software&nbsp;</span></h1>
           <h2>Compelling Software &bull; Design & Construction</h3>
        </div>
      
        <div id="header" class="screenOnly">
          <h1>
            Andrew J. Peterson
          </h1>
        <h1>
          Compelling Software, Design and Development
        </h1>
      <h1>
        NDP Software
      </h1>
    <h1>
      Andrew Peterson, Consultant
    </h1>
</div>
<div id="menu" class="screenOnly">
  <div class="menu">
    <ul>
      <!--li>
        NDP Software 
      </li-->
      <li>
        <a href="index.php" title="Overview of the software consulting business">
          About NDP Software
        </a>
      </li>
      <li>
        <a href="visualization.php" title="Interactions and Visualizations">
          Visualization
        </a>
      </li>
      <li>
        <a href="prototype.php" title="Prototypes">
          Prototype
        </a>
      </li>
      <li>
        <a href="consulting.php" title="Consulting projects and areas of expertise">
          Software Consultant
        </a>
      </li>
<!--      <li>
        <a href="web.php" title="Web-related software projects">
          Web Development
        </a>
      </li>
      <li>
        <a href="software.php" title="Custom-built software">
          Software Development
        </a>
      </li> -->
      <li>
        <a href="clients.php" title="Clients of NDP Software">
          Clients
        </a>
      </li>
      <li>
        <a href="http://blog.ndpsoftware.com/" target="_blank">Blog</a>
      </li>
      <li>
        <a href="http://github.com/ndp" target="_blank">Github Repo</a>
      </li>
      <li>
        <a href="http://amp-what.com" target="_blank">Amp What</a>
      </li>
      <li>
        <a href="https://plus.google.com/111325326458556506982/posts?rel=author">Google+</a>
      </li>
      <li class="email">
         <a href="mailto:andy@ndpsoftware.com">Email</a>
      </li>
      <li class="linked_in">
        <script src="//platform.linkedin.com/in.js" type="text/javascript"></script>
        <script type="IN/MemberProfile" data-id="http://www.linkedin.com/in/ndpsoftware" data-format="hover" data-related="false"></script>
      </li>
      <!--li class="social">
        <g:plusone size="small" annotation="inline" width="160"></g:plusone>
      </li-->
    </ul>
  </div>
</div>
<div id="content">
  <h2>
Software Development Maturity Model  </h2>
<p>Re-writing the buggiest function in the system offers much more benefit than working on a relatively stable area.
The same goes for organizations: if the salespeople close dozens of deals, but there are no programmers to
  create the vaporware, spending more money training salespeople won't help. Fix the development team.
This is obvious, but notion of identifying a software organization's weakness was the germ of the
idea outlined below.</p>
<p>I've worked with dozens of organizations through the years, and all have their strengths and weaknesses.
I've been asked numerous times to assess "how's our software development process going?" I can certainly
dig in and see their weaknesses, but having an external grading system, like the table below, allows
more reasoned recommendation.</p>
<p>The following table summarizes categories of software development maturity within an organization. It was
  inspired by the CMM (capability maturity model), but in no way tries to emulate it.</p>
<p>To use this table, first assess where the organization is with respect to each area.
  From my experience, most organization won't fit simply
  into one maturity level, rather different levels in different areas. They are better at some things
  more than others. For example, it's common to have source code control working well, but no bug tracking system. </p>
<p>Once you have done this assessment, the organizations strengths and weaknesses will be more apparent.
  The CMM echo that before becoming mature in one area, and organization should address the other areas first.
  This simply means focus on improving the areas where you are weakest. Focusing on the weakest areas will provide
  the most benefit for the organizational change investment.
  That was the idea behind putting this table together.</p>
<p>Level 1 is the lowest level. Often it is characterized by "surprises". It is indicated by a software organization that has delivered a piece of software, and
  unfortunately, many organizations are not at this level.</p>
<p>Level 2 organizations have delivered software repeatedly, but not without significant hiccups. Often it is characterized
  by "disappointment". There are misfires,
abandoned projects, but the software is going out.</p>
        <p>Level 3 is the mature software organization that is has the people and projects aligned. Opportunities
          are identified, software created, and customers satisfied. There will
        be mistakes, but they are identified as early as possible. </p>

<style>
  table.mod {
    border: none;
    margin-bottom: 4ex;
  }

  table.mod tr {

  }

  table.mod tr td,
  table.mod tr th {
    width:  36%;
    vertical-align: top;
    border: none;
    font-size: 13px;
    padding: 1ex 4ex 1ex 0;
  }
  table.mod tr td:nth-child(3),
  table.mod tr th:nth-child(3) {
    width: 28%;
    padding-right: 0;
  }


  table.mod tr td {
    text-align:  left;
  }

  table.mod thead {
    display: none;
  }
  table.mod thead tr th {
    font-size: 15px;
  }

  table.mod tbody tr th {
    font-weight: normal;
    font-style: normal;
    border-bottom:  1px solid #ccc;
    font-variant:  small-caps;
    color: #555;
    padding-top: 4ex;
  }

  table.mod tbody tr td:nth-child(1):before {
    content: 'Level 1: ';
    font-weight: bold;
  }
  table.mod tbody tr td:nth-child(2):before {
    content: 'Level 2: ';
    font-weight: bold;
  }
  table.mod tbody tr td:nth-child(3):before {
    content: 'Level 3: ';
    font-weight: bold;
  }
</style>

<table class="mod" cellspacing="0">
  <thead>
  <tr>
    <th>Level 1</th>
    <th>Level 2</th>
    <th>Level 3</th>
  </tr>
  </thead>
  <tbody>
  <tr>
    <th colspan="3">requirements, product and project management</th>
  </tr>
  <tr>
    <td>the working software outlines the requirements; future requirements may be identified, but they are un-prioritized, incomplete;
      the process is chaotic or ad hoc; quickly changing product vision; success may
      require heroics; failures; abandoned projects
    </td>
    <td>active project management, consistent successes; published, prioritized requirements (or user stories); combined
      with fire
      drills, late or buggy releases; the product development process is defined, although not necessarily followed or
      effective
    </td>
    <td>predictable success; agile, efficient, maximize value; institutionalized, optimizing; both strategic and
      tactical plans, with the ability to be opportunistic; seldom build low-value features; shared understanding of
      process; ability to re-prioritize requirements efficiently; reliable estimates; risk management
    </td>
  </tr>
  <tr>
    <th colspan="3">programming team</th>
  </tr>
  <tr>
    <td>individuals build the products</td>
    <td>functional team, code ownership, code style guide; shared designs as needed</td>
    <td>shared code ownership, shared software designs, patterns and strategy; code style compliance,
      code reviews; professional development, cross-training;
    </td>
  </tr>
  <tr>
    <th colspan="3">Code</th>
  </tr>
  <tr>
    <td>"Hey, it works!"; silo-ed knowledge; code mine-fields and buggy areas; home-grown solutions;
      unmodifiable legacy areas
    </td>
    <td>works well; some legacy problem areas; core business concepts validated and documented; duplicate solutions to
      same problems
    </td>
    <td>collective ownership; consistency; organized; modern patterns and tools; integrated modern tools</td>
  </tr>
  <tr>
    <th colspan="3">quality control</th>
  </tr>
  <tr>
    <td>defect tracking system includes post-its and to-do lists; for QA, everyone chips in, or "sales team looks it
      over"
    </td>
    <td>defect tracking system, QA plan; functional tests; may have some automated testing, unit testing; most changes
      go
      through system testing, but may be emergency fixes that skip process
    </td>
    <td>integrated in development; continuous integration,
      code coverage metrics,
      other software metrics as needed; QA plan in place and executed
    </td>
  </tr>
  <tr>
    <th colspan="3">programming tools</th>
  </tr>
  <tr>
    <td>tools (editors, compilers, etc.)</td>
    <td>modern, professional tools</td>
    <td>unified, modern and professional tools</td>
  </tr>
  <tr>
    <th colspan="3">source code management and builds (configuration management)</th>
  </tr>
  <tr>
    <td>have the source code in hand, backups, numbered releases</td>
    <td>modern tool such as svn, cvs, git, p4, etc.; mostly script-able builds</td>
    <td>linkage of code changes to requirements and bugs; visibility and metrics into code; fully-scripted and automated
      builds;
    </td>
  </tr>
  <tr>
    <th colspan="3">release process</th>
  </tr>
  <tr>
    <td>determined (or delayed) by software quality and feature completion</td>
    <td>scheduled based on feature completion at regular intervals; early planning sacrifices features; late sacrifice
      of quality or ship date
    </td>
    <td>always releasable quality; maintain quality and release date; sacrifice low-value features</td>
    </td>
  </tr>
  <!--<tr>-->
    <!--<th colspan="3">it, hosting</th>-->
  <!--</tr>-->
  <!--<tr>-->
    <!--<td>part-time team, "Hey, it works!"</td>-->
    <!--<td>full-time team, process to handle alerts</td>-->
    <!--<td>full-time team, scriptable solutions</td>-->
  <!--</tr>-->
  <!--<tr>-->
    <!--<th colspan="3"></th>-->
  <!--</tr>-->
  <!--<tr>-->
    <!--<td></td>-->
    <!--<td></td>-->
    <!--<td></td>-->
  <!--</tr>-->
  </tbody>
</table>

<p>Copyright (c) 2007-2013 NDP Software. All Rights Reserved. This article is translated to <a href="http://science.webhostinggeeks.com/razvoj-softwera">Serbo-Croatian</a>
  language by Anja Skrba from <a href="http://webhostinggeeks.com/"> Webhostinggeeks.com</a>.</p>


</div>
<!--id content -->
<div id="footer" >
  <table class="sitemap screenOnly">
    <tr>
      <td>
        <div class="menu cheatsheets">
          <ul>
            <li title="Short summaries of detailed technical topics">
              Cheat Sheets 
            </li>
            <li>
              <a class="new" href="git-cheatsheet.html">
                Visual Git Cheatsheet
              </a>
            </li>
            <li>
              <a href="HibernateMappingCheatSheet.html" title="Short hibernate mapping examples, without the detailed explanations.">
                Hibernate Mapping
              </a>
            </li>
            <li>
              <a class="updated" href="JSPXMLCheatSheet.html" title="JSPs with XML? A simple summary of the most useful and used constructs">
                JSP 2.0 XML Documents
              </a>
            </li>
            <li>
              <a href="http://amp-what.com" title="A quick, interactive reference of 11,500 HTML character entities">&amp;what (amp-what.com)</a>
            </li>
            <li>
              XSLT 
            </li>
            <li>
              <a href="downloads-xsl-struts.php">
                Struts Xslt
              </a>
            </li>
            <li>
              <a href="downloads-xsl-resume.php">
                Xslt for My Resume
              </a>
            </li>
          </ul>
        </div>
      </td>
      <td>
        <div class="menu technical">
          <ul>
            <li>
              CSS 
            </li>
            <li>
              <a class="updated" href="CssBestPractices.php">
                CSS Best Practices
              </a>
            </li>
            <li>
              <a href="cssExperiments.php">
                CSS Experiments
              </a>
            </li>
            <li>
              <a href="css.php">
                CSS Links
              </a>
            </li>
            <li>
              Javascript 
            </li>
            <li>
              <a href="http://github.com/ndp/csster" class="new" >
                Csster
              </a>
            </li>
            <li>
              <a href="ScriptaculousEffectsDemo.php" class="new" >
                Scriptaculous Effects Demo
              </a>
            </li>
            <li>
                <a href="http://github.com/ndp/jsutils" class="new" >
                    Javascript Playground
                </a>
            </li>
            <li>
              jQuery Plugins
            </li>
            <li>
              <a href="show_char_limit.php" class="new" >
                Show Char Limit
              </a>
            </li>
            <li>
              <a href="http://github.com/ndp/align-column" class="new" >
                Align Column
              </a>
            </li>
            <li>
              <a href="http://github.com/ndp/fixie" class="new" >
                Fixie
              </a>
            </li>
            <li>
              <a href="http://github.com/ndp/wizardize" class="new" >
                Wizardize
              </a>
            </li>
            <li>
              <a href="http://github.com/ndp/color_spy" class="new" >
                Color Spy
              </a>
            </li>
          </ul>
        </div>
      </td>
      <td>
        <div class="menu technical">
          <ul>
            <li>
              Other Technical 
            </li>
            <!--li>
              <a href="books.php" title="Books we like">
                Books
              </a>
            </li-->
            <li>
              <a href="isbn.php">
                ISBN Excel Converter
              </a>
            </li>
            <li>
              <a class="new" href="agile_methods/agile_methods.html">
                Agile Methods Visualization
              </a>
            </li>
            <li>
              <a class="new" href="softwareDevMaturityModel.php">
                Software Development Maturity Model
              </a>
            </li>
            <li>
              <a class="new" href="/OpenUpBasic/index.htm" target="_blank">
                OpenUP/Basic
              </a>
            </li>
            <li>
              <a class="new" href="other.php">
                Other Projects
              </a>
            </li>
            <li>
              <a href="http://blog.ndpsoftware.com/" target="_blank">My Blog</a>
            </li>
            <li>
              <a href="about.php"> 
                About This Site
              </a>
            </li>
          </ul>
        </div>
      </td>
      <td>
        <div class="menu nontechnical">
          <ul>
            <li>
              Non-technical 
            </li>
            <li>
              <a href="http://delicious.com/ndp" target="_blank">
                  delicious/ndp
              </a>
            </li>
            <li>
              <a href="http://ical.mac.com/WebObjects/iCal.woa/wa/default?u=ndp&amp;n=ndp.ics" target="_blank">
                Calendar
              </a>
            </li>
            <li>
              <a href="construction.php">
                Construction
              </a>
            </li>
            <!--<li>-->
              <!--<a href="http://priita.com" target="_blank">-->
                <!--Priita.com-->
              <!--</a>-->
            <!--</li>-->
            <!--<li>-->
              <!--<a href="http://homepage.mac.com/ndp" target="_blank">-->
                <!--Photos-->
              <!--</a>-->
            <!--</li>-->
            <!--<li>-->
              <!--<a href="http://tanyandy.com" target="_blank">-->
                <!--Tanyandy.com-->
              <!--</a>-->
            <!--</li>-->
          </ul>
        </div>
      </td>
    </tr>
  </table>
  <div class="footnotes screenOnly">
    <div class="menu technical">
      <ul>
        <li>
          <span class='st_email'></span>
            <span class='st_stumbleupon'></span>
             <span class='st_twitter'></span>
            <span class='st_googleplus'></span>
            <span class='st_facebook'></span>
            <span class='st_wordpress'></span>
            <span class='st_hatena'></span>
            <span class='st_delicious'></span>
            <span class='st_blogger'></span>
            <span class='st_tumblr'></span>
            <span class='st_reddit'></span>
            <span class='st_linkedin'></span>
        </li>
      </ul>
    </div>
  </div>
  <div class="copyright">
    Copyright (c) 1999-2013 Andrew J. Peterson.
    <a href="mailto:andy@ndpsoftware.com">
      andy@ndpsoftware.com</a>. 
  </div>

</div>
</div>
</div>
<script type="text/javascript">
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>      
<script type="text/javascript">var switchTo5x=false;</script><script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script><script type="text/javascript">stLight.options({publisher:'34a76a8b-d635-4885-8b9c-78fbf9a6d08d'});</script>
</body>
</html>
