<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>
      NDP Software ::
Prototypes    </title>
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0"/>
    <link rel="SHORTCUT ICON" href="favicon.ico" />
    <meta name="msvalidate.01" content="B24F365C5258BA8C65E423307692C32E" />
        <link rel="stylesheet" href="fonts/Impact-Label-fontfacekit/stylesheet.css" type="text/css"/>
    <link rel="stylesheet" type="text/css" href="css/ndp-print.css" media="print" />
    <link rel="stylesheet" type="text/css" href="css/ndp.css" media="screen" />
            <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script type="text/javascript" src="js/csster.js"></script>
    <script type="text/javascript" src="js/color_factory.js"></script>
    <script type="text/javascript" src="js/jquery.boxes.js"></script>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-1458227-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>


  </head>
  <body class="" onload="">
    <div id="margin">
      <div id="page">
        <div id="new_header">
           <h1><span>&nbsp;NDP Software&nbsp;</span></h1>
           <h2>Compelling Software &bull; Design & Construction</h3>
        </div>
      
        <div id="header" class="screenOnly">
          <h1>
            Andrew J. Peterson
          </h1>
        <h1>
          Compelling Software, Design and Development
        </h1>
      <h1>
        NDP Software
      </h1>
    <h1>
      Andrew Peterson, Consultant
    </h1>
</div>
<div id="menu" class="screenOnly">
  <div class="menu">
    <ul>
      <!--li>
        NDP Software 
      </li-->
      <li>
        <a href="index.php" title="Overview of the software consulting business">
          About NDP Software
        </a>
      </li>
      <li>
        <a href="visualization.php" title="Interactions and Visualizations">
          Visualization
        </a>
      </li>
      <li>
        <a href="prototype.php" title="Prototypes">
          Prototype
        </a>
      </li>
      <li>
        <a href="consulting.php" title="Consulting projects and areas of expertise">
          Software Consultant
        </a>
      </li>
<!--      <li>
        <a href="web.php" title="Web-related software projects">
          Web Development
        </a>
      </li>
      <li>
        <a href="software.php" title="Custom-built software">
          Software Development
        </a>
      </li> -->
      <li>
        <a href="clients.php" title="Clients of NDP Software">
          Clients
        </a>
      </li>
      <li>
        <a href="http://blog.ndpsoftware.com/" target="_blank">Blog</a>
      </li>
      <li>
        <a href="http://github.com/ndp" target="_blank">Github Repo</a>
      </li>
      <li>
        <a href="http://amp-what.com" target="_blank">Amp What</a>
      </li>
      <li>
        <a href="https://plus.google.com/111325326458556506982/posts?rel=author">Google+</a>
      </li>
      <li class="email">
         <a href="mailto:andy@ndpsoftware.com">Email</a>
      </li>
      <li class="linked_in">
        <script src="//platform.linkedin.com/in.js" type="text/javascript"></script>
        <script type="IN/MemberProfile" data-id="http://www.linkedin.com/in/ndpsoftware" data-format="hover" data-related="false"></script>
      </li>
      <!--li class="social">
        <g:plusone size="small" annotation="inline" width="160"></g:plusone>
      </li-->
    </ul>
  </div>
</div>
<div id="content">
  <h2>
Prototypes  </h2>

<p>Tools (and processes) 
have evolved such that we can have working applications available to the world
within an hour, and can test ideas with working software within hours and days.
"Software" spent years playing the part of the brittle and ornery partner; it's
  finally becoming a little more "soft". </p>
<div id="sidebar">
  <p>Praise from around the web for <a href="http://www.ndpsoftware.com/git-cheatsheet.html" target="_blank">Inter&shy;active
    Git Visual&shy;i&shy;za&shy;tion</a>:</p>
  <blockquote>A very, very well done cheat sheet</blockquote>
  <blockquote>A worksheet that helps me "get git":</blockquote>
  <blockquote>Awesome work on your Git Cheatsheet. One of the best I've seen, and I've been using it a lot :-)
  </blockquote>
  <blockquote>Awesome visualization of common & useful git commands</blockquote>
  <blockquote>extra&shy;or&shy;di&shy;nario progra&shy;maci&oacute;n ejemplo git cheat&shy;sheet ndpsoftware.com</blockquote>
</div>

<p>To pull this off takes a combination of the right tools and the right
software development practices. State-of-the-art tools like cloud
deployments, Rails,
Javascript, and some home-grown ones like <a href="http://github.com/ndp/csster" target="_blank">Csster</a>,
remove the roadblocks to delivering software quickly.
Couple this with agile development practices that help divine the best
features to implement next, and you can move quickly.</p>



<h3>Quick Projects</h3>

<p>We developed <a href="http://www.ndpsoftware.com/git-cheatsheet.html" target="_blank">this visualization</a> to clarify Git's complexities. We
  built it while learning Git, and many others use it as well. This required gathering the data and has had several
iterations since the initial prototype. The initial version took just a couple hours.
After positive feedback we devoted time to fleshing out the text and responding
to user requests.</p>

<p>A one-day project, <a href="http://ndpsoftware.com/linkedin/" target="_blank">LinkedIn Timeline</a>,
Andy scratched an itch of many years to build time lines. This project involved learning
the basics of their API, solving a few design problems, and implementing
a working version. We built up a list of problems along the way, and this addresses
some of them... many were left for another day.</p>

<p>Andy built the first prototype of CarbonFive's <a href="http://trackerstorymaps.com/" target="_blank">Story Mapper</a>
  and contributed to ongoing development
  and project management. (The link requires Pivotal Tracker login). This was a couple hours devoted to a "spike"
implementation, which convinced the team to devote more resources to the project. Intial prototype approx 2 hours</p>

<p><a href="http://uxspoke.com/" target="_blank">UX Spoke</a> addresses common software usability questions.
  As you develop or refine a software product, it's easy to get stuck in a rut, running user tests that aren't
  that helpful or focusing too much on Google Analytics. A tool that worked well may no longer be the
  right tool for the new questions you have now. The UX/Spoke tool is designed to help you explore
  many of the different tools in common practice. Approx 3 days, mixed with learning several new technologies</p>

<p>A quick <a href="http://blog.ndpsoftware.com/2010/09/most-resumes-are-pretty-boring.html#more" target="_blank">chart
  of the programming languages Andy has used</a>. Created to demonstrate concise CSS and Javascript style. Approx 1 hour</p>

<p><a href="http://blog.ndpsoftware.com/2009/09/scrum-xp-agile-and-visualizing.html" target="_blank">Agile Processes</a> is
  a quick visualization to understand the differences between "agile", XP, scrum, etc. Approx 1 day</p>

<p><a href="http://difftionary.com" target="_blank">Difftionary</a> &mdash; Online dictionary of distinctions. Site concept.</p>

<h3>Longer Projects</h3>

<p>Over a six-month period,
  Andy led the initial development of <a href="http://vark.com/" target="_blank">Aardvark</a>, in collaboration with the
  Aardvark team,
  building a prototype that evolved into the core engine.</p>

<p>On <a href="http://bedsider.org">Bedsider</a>, Andy spent a month building an in-depth prototype of a new application, the
  <a href="http://bedsider.org/bootylog">BootyLog</a>, including
visualizations and database-backed functionality.</p>

<p><a href="http://amp-what.com" target="_blank">&amp;what;</a> is a programmer utility to discover various character entities. This is a prototype
to utilize features of HTML5, as well as provide some utility. Initial version took
just a couple hours, and the current implementation has been iterated on many times.</p>

<p><a href="http://chklistr.com" target="_blank">Chklistr</a> &mdash; Find, use and share all sorts of checklists. Site concept.</p>


</div>
<!--id content -->
<div id="footer" >
  <table class="sitemap screenOnly">
    <tr>
      <td>
        <div class="menu cheatsheets">
          <ul>
            <li title="Short summaries of detailed technical topics">
              Cheat Sheets 
            </li>
            <li>
              <a class="new" href="git-cheatsheet.html">
                Visual Git Cheatsheet
              </a>
            </li>
            <li>
              <a href="HibernateMappingCheatSheet.html" title="Short hibernate mapping examples, without the detailed explanations.">
                Hibernate Mapping
              </a>
            </li>
            <li>
              <a class="updated" href="JSPXMLCheatSheet.html" title="JSPs with XML? A simple summary of the most useful and used constructs">
                JSP 2.0 XML Documents
              </a>
            </li>
            <li>
              <a href="http://amp-what.com" title="A quick, interactive reference of 11,500 HTML character entities">&amp;what (amp-what.com)</a>
            </li>
            <li>
              XSLT 
            </li>
            <li>
              <a href="downloads-xsl-struts.php">
                Struts Xslt
              </a>
            </li>
            <li>
              <a href="downloads-xsl-resume.php">
                Xslt for My Resume
              </a>
            </li>
          </ul>
        </div>
      </td>
      <td>
        <div class="menu technical">
          <ul>
            <li>
              CSS 
            </li>
            <li>
              <a class="updated" href="CssBestPractices.php">
                CSS Best Practices
              </a>
            </li>
            <li>
              <a href="cssExperiments.php">
                CSS Experiments
              </a>
            </li>
            <li>
              <a href="css.php">
                CSS Links
              </a>
            </li>
            <li>
              Javascript 
            </li>
            <li>
              <a href="http://github.com/ndp/csster" class="new" >
                Csster
              </a>
            </li>
            <li>
              <a href="ScriptaculousEffectsDemo.php" class="new" >
                Scriptaculous Effects Demo
              </a>
            </li>
            <li>
                <a href="http://github.com/ndp/jsutils" class="new" >
                    Javascript Playground
                </a>
            </li>
            <li>
              jQuery Plugins
            </li>
            <li>
              <a href="show_char_limit.php" class="new" >
                Show Char Limit
              </a>
            </li>
            <li>
              <a href="http://github.com/ndp/align-column" class="new" >
                Align Column
              </a>
            </li>
            <li>
              <a href="http://github.com/ndp/fixie" class="new" >
                Fixie
              </a>
            </li>
            <li>
              <a href="http://github.com/ndp/wizardize" class="new" >
                Wizardize
              </a>
            </li>
            <li>
              <a href="http://github.com/ndp/color_spy" class="new" >
                Color Spy
              </a>
            </li>
          </ul>
        </div>
      </td>
      <td>
        <div class="menu technical">
          <ul>
            <li>
              Other Technical 
            </li>
            <!--li>
              <a href="books.php" title="Books we like">
                Books
              </a>
            </li-->
            <li>
              <a href="isbn.php">
                ISBN Excel Converter
              </a>
            </li>
            <li>
              <a class="new" href="agile_methods/agile_methods.html">
                Agile Methods Visualization
              </a>
            </li>
            <li>
              <a class="new" href="softwareDevMaturityModel.php">
                Software Development Maturity Model
              </a>
            </li>
            <li>
              <a class="new" href="/OpenUpBasic/index.htm" target="_blank">
                OpenUP/Basic
              </a>
            </li>
            <li>
              <a class="new" href="other.php">
                Other Projects
              </a>
            </li>
            <li>
              <a href="http://blog.ndpsoftware.com/" target="_blank">My Blog</a>
            </li>
            <li>
              <a href="about.php"> 
                About This Site
              </a>
            </li>
          </ul>
        </div>
      </td>
      <td>
        <div class="menu nontechnical">
          <ul>
            <li>
              Non-technical 
            </li>
            <li>
              <a href="http://delicious.com/ndp" target="_blank">
                  delicious/ndp
              </a>
            </li>
            <li>
              <a href="http://ical.mac.com/WebObjects/iCal.woa/wa/default?u=ndp&amp;n=ndp.ics" target="_blank">
                Calendar
              </a>
            </li>
            <li>
              <a href="construction.php">
                Construction
              </a>
            </li>
            <!--<li>-->
              <!--<a href="http://priita.com" target="_blank">-->
                <!--Priita.com-->
              <!--</a>-->
            <!--</li>-->
            <!--<li>-->
              <!--<a href="http://homepage.mac.com/ndp" target="_blank">-->
                <!--Photos-->
              <!--</a>-->
            <!--</li>-->
            <!--<li>-->
              <!--<a href="http://tanyandy.com" target="_blank">-->
                <!--Tanyandy.com-->
              <!--</a>-->
            <!--</li>-->
          </ul>
        </div>
      </td>
    </tr>
  </table>
  <div class="footnotes screenOnly">
    <div class="menu technical">
      <ul>
        <li>
          <span class='st_email'></span>
            <span class='st_stumbleupon'></span>
             <span class='st_twitter'></span>
            <span class='st_googleplus'></span>
            <span class='st_facebook'></span>
            <span class='st_wordpress'></span>
            <span class='st_hatena'></span>
            <span class='st_delicious'></span>
            <span class='st_blogger'></span>
            <span class='st_tumblr'></span>
            <span class='st_reddit'></span>
            <span class='st_linkedin'></span>
        </li>
      </ul>
    </div>
  </div>
  <div class="copyright">
    Copyright (c) 1999-2013 Andrew J. Peterson.
    <a href="mailto:andy@ndpsoftware.com">
      andy@ndpsoftware.com</a>. 
  </div>

</div>
</div>
</div>
<script type="text/javascript">
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>      
<script type="text/javascript">var switchTo5x=false;</script><script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script><script type="text/javascript">stLight.options({publisher:'34a76a8b-d635-4885-8b9c-78fbf9a6d08d'});</script>
</body>
</html>
